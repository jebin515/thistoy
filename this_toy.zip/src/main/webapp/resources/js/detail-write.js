var swiper2 = new Swiper(".mySwiper2", {
    loop: false,
    spaceBetween: 4,
    slidesPerView: 1,
    initialslide: 1,
    roundLengths:true,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
   
  });