package com.base.entity;

public class test {

}
