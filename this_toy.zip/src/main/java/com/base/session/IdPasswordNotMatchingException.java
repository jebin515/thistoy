package com.base.session;

public class IdPasswordNotMatchingException extends RuntimeException{

}
