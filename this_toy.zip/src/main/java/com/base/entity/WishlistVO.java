package com.base.entity;

import lombok.Data;

@Data
public class WishlistVO {

	private int wishCode;
	private String productCode;
	private String userId;
}
