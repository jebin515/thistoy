package com.base.entity;

import lombok.Data;

@Data
public class DownCategoryVO {
	private String downCaCode;
	private String upCaCode;
	private String downCaName;
}
