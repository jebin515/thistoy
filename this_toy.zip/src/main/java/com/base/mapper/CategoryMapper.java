package com.base.mapper;

import java.util.ArrayList;

import com.base.entity.DownCategoryVO;

public interface CategoryMapper {

	ArrayList<DownCategoryVO> select();
	
	DownCategoryVO getDcName(String downCaCode);
}
