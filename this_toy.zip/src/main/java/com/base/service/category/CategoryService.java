package com.base.service.category;

import java.util.ArrayList;

import com.base.entity.DownCategoryVO;

public interface CategoryService {

	ArrayList<DownCategoryVO> getList();
	
	DownCategoryVO getDcName(String downCaCode);
}
