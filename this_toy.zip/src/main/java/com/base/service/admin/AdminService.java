 package com.base.service.admin;

import java.util.ArrayList;

import com.base.entity.UserVO;

public interface AdminService {
 
	ArrayList<UserVO> admin();
	
	String deleteMember(String userId);
 }
 
